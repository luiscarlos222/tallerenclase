package com.mycompany.listabasica;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // ── 1. Crear la lista enlazada ─────────────────────────────────────
        ListaEnlazada lista = new ListaEnlazada();

        System.out.println("=== EJERCICIO 1 — LISTA ENLAZADA BÁSICA ===\n");

        // ── 2. Insertar nodos (datos capturados por teclado) ───────────────
        System.out.print("¿Cuántos datos quieres insertar? ");
        int cantidad = sc.nextInt();

        for (int i = 1; i <= cantidad; i++) {
            System.out.print("Escribe el dato " + i + ": ");
            int dato = sc.nextInt();
            lista.insertar(dato);
        }
        System.out.println();
        lista.mostrar();

        // ── 3. Tamaño ──────────────────────────────────────────────────────
        System.out.println("\n▶ Tamaño de la lista: " + lista.tamanio());

        // ── 4. Buscar (dato capturado por teclado) ─────────────────────────
        System.out.print("\nEscribe el dato que quieres buscar: ");
        int buscado = sc.nextInt();
        System.out.println("▶ Buscar " + buscado + ": " + lista.buscar(buscado));

        // ── 5. Eliminar (dato capturado por teclado) ───────────────────────
        System.out.print("\nEscribe el dato que quieres eliminar: ");
        int eliminado = sc.nextInt();
        System.out.println("▶ Eliminando nodo con dato " + eliminado + "...");
        lista.eliminar(eliminado);
        lista.mostrar();

        // ── 6. Anatomía de un Nodo (datos capturados por teclado) ──────────
        System.out.println("\n=== ANATOMÍA DE UN NODO ===");
        System.out.print("Escribe el dato del nodo 1: ");
        Nodo n1 = new Nodo(sc.nextInt());
        System.out.print("Escribe el dato del nodo 2: ");
        Nodo n2 = new Nodo(sc.nextInt());
        System.out.print("Escribe el dato del nodo 3: ");
        Nodo n3 = new Nodo(sc.nextInt());

        n1.enlace = n2;   // n1 → n2
        n2.enlace = n3;   // n2 → n3

        System.out.println("n1.dato              = " + n1.dato);
        System.out.println("n1.enlace            = " + n1.enlace);
        System.out.println("n1.enlace.enlace     = " + n1.enlace.enlace);
        System.out.println("cadena: " + n1 + " → " + n2 + " → " + n3 + " → null");

        sc.close();
    }
}